"""
Network-based SEIRD/SEIHRD Simulation Engine for Bundibugyo VD
Adapted from ExDiff SIRVD framework - FIXED isolation logic
"""
import numpy as np
import networkx as nx
from collections import defaultdict

STATE_NAMES_SEIRD = {0: 'S', 1: 'E', 2: 'I', 3: 'R', 4: 'D'}
STATE_NAMES_SEIHRD = {0: 'S', 1: 'E', 2: 'I', 3: 'H', 4: 'R', 5: 'D*', 6: 'D'}

class NetworkSEIRDSimulation:
    """Stochastic SEIRD simulation on a contact network."""
    def __init__(self, graph, params, I0=1, seed=None):
        self.graph = graph
        self.N = graph.number_of_nodes()
        self.params = params
        self.rng = np.random.default_rng(seed)
        self.I0 = I0

    def initialize_states(self):
        states = np.zeros(self.N, dtype=int)
        initial_infected = self.rng.choice(self.N, size=min(self.I0, self.N), replace=False)
        states[initial_infected] = 2
        return states

    def state_transition(self, states, vaccinated_nodes=None, isolated_nodes=None):
        """Isolated infectious nodes cannot transmit to neighbors."""
        new_states = states.copy()
        p = self.params
        for node in range(self.N):
            current = states[node]
            if current == 0:
                if vaccinated_nodes is not None and node in vaccinated_nodes:
                    new_states[node] = 3; continue
                neighbors = list(self.graph.neighbors(node))
                n_infected = sum(1 for nb in neighbors 
                                if states[nb] == 2 and 
                                (isolated_nodes is None or nb not in isolated_nodes))
                if n_infected > 0:
                    if self.rng.random() < 1 - (1 - p['beta']) ** n_infected:
                        new_states[node] = 1
            elif current == 1:
                if self.rng.random() < p['sigma']:
                    new_states[node] = 2
            elif current == 2:
                if self.rng.random() < p['gamma']:
                    new_states[node] = 4 if self.rng.random() < p['f'] else 3
        return new_states

    def simulate(self, n_steps, vaccinated_nodes=None, isolated_nodes=None):
        states = self.initialize_states()
        history = [states.copy()]
        for t in range(n_steps):
            states = self.state_transition(states, vaccinated_nodes, isolated_nodes)
            history.append(states.copy())
            if np.sum(states == 2) == 0 and np.sum(states == 1) == 0: break
        return np.array(history)

    def compute_metrics(self, history):
        n_steps = len(history)
        counts = defaultdict(list)
        for t in range(n_steps):
            for sid, name in STATE_NAMES_SEIRD.items():
                counts[name].append(np.sum(history[t] == sid))
        peak_I = max(counts['I']); peak_day = np.argmax(counts['I'])
        total_D = counts['D'][-1]; total_R = counts['R'][-1]
        attack_rate = (total_R + total_D) / self.N * 100
        return {'peak_infectious': int(peak_I), 'peak_day': int(peak_day),
                'total_deaths': int(total_D), 'total_recovered': int(total_R),
                'attack_rate_pct': round(attack_rate, 2), 'epidemic_duration': n_steps,
                'final_S': int(counts['S'][-1]), 'final_E': int(counts['E'][-1])}


class NetworkSEIHRDSimulation:
    """Stochastic SEIHRD simulation on a contact network (Ebola-specific)."""
    def __init__(self, graph, params, I0=1, seed=None):
        self.graph = graph
        self.N = graph.number_of_nodes()
        self.params = params
        self.rng = np.random.default_rng(seed)
        self.I0 = I0

    def initialize_states(self):
        states = np.zeros(self.N, dtype=int)
        initial_infected = self.rng.choice(self.N, size=min(self.I0, self.N), replace=False)
        states[initial_infected] = 2
        return states

    def state_transition(self, states, vaccinated_nodes=None, isolated_nodes=None, safe_burial_nodes=None):
        """Isolated infectious nodes cannot transmit. Safe burial reduces D* transmission and speeds burial."""
        new_states = states.copy()
        p = self.params
        for node in range(self.N):
            current = states[node]
            if current == 0:
                if vaccinated_nodes is not None and node in vaccinated_nodes:
                    new_states[node] = 4; continue
                neighbors = list(self.graph.neighbors(node))
                n_I = sum(1 for nb in neighbors if states[nb] == 2 and 
                         (isolated_nodes is None or nb not in isolated_nodes))
                n_H = sum(1 for nb in neighbors if states[nb] == 3)
                n_Dstar_infectious = 0
                for nb in neighbors:
                    if states[nb] == 5:
                        if safe_burial_nodes is not None and nb in safe_burial_nodes:
                            n_Dstar_infectious += 0.2
                        else:
                            n_Dstar_infectious += 1
                prob_no_inf = 1.0
                if n_I > 0: prob_no_inf *= (1 - p['beta']) ** n_I
                if n_H > 0: prob_no_inf *= (1 - p['beta_H']) ** n_H
                if n_Dstar_infectious > 0: prob_no_inf *= (1 - p['beta_F']) ** n_Dstar_infectious
                if self.rng.random() < 1 - prob_no_inf: new_states[node] = 1
            elif current == 1:
                if self.rng.random() < p['sigma']: new_states[node] = 2
            elif current == 2:
                if self.rng.random() < p['alpha']: new_states[node] = 3
                elif self.rng.random() < p['gamma_I']:
                    new_states[node] = 5 if self.rng.random() < p['f_I'] else 4
            elif current == 3:
                if self.rng.random() < p['gamma_H']:
                    new_states[node] = 5 if self.rng.random() < p['f_H'] else 4
            elif current == 5:
                gamma_D = p['gamma_D']
                if safe_burial_nodes is not None and node in safe_burial_nodes:
                    gamma_D = min(1.0, gamma_D * 4)
                if self.rng.random() < gamma_D: new_states[node] = 6
        return new_states

    def simulate(self, n_steps, vaccinated_nodes=None, isolated_nodes=None, safe_burial_nodes=None):
        states = self.initialize_states()
        history = [states.copy()]
        for t in range(n_steps):
            states = self.state_transition(states, vaccinated_nodes, isolated_nodes, safe_burial_nodes)
            history.append(states.copy())
            active = np.sum(states == 2) + np.sum(states == 1) + np.sum(states == 3) + np.sum(states == 5)
            if active == 0: break
        return np.array(history)

    def compute_metrics(self, history):
        n_steps = len(history)
        counts = defaultdict(list)
        for t in range(n_steps):
            for sid, name in STATE_NAMES_SEIHRD.items():
                counts[name].append(np.sum(history[t] == sid))
        peak_I = max(counts['I']); peak_day = np.argmax(counts['I'])
        total_D = counts['D'][-1]; total_R = counts['R'][-1]
        attack_rate = (total_R + total_D) / self.N * 100
        return {'peak_infectious': int(peak_I), 'peak_day': int(peak_day),
                'peak_hospitalized': int(max(counts['H'])),
                'peak_dead_not_buried': int(max(counts['D*'])),
                'total_deaths': int(total_D), 'total_recovered': int(total_R),
                'attack_rate_pct': round(attack_rate, 2), 'epidemic_duration': n_steps,
                'final_S': int(counts['S'][-1]), 'final_E': int(counts['E'][-1])}


def random_vaccination(graph, fraction, rng):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    return set(rng.choice(N, size=n_vax, replace=False))

def targeted_vaccination(graph, fraction, method='betweenness'):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    if method == 'betweenness': centrality = nx.betweenness_centrality(graph)
    elif method == 'degree': centrality = dict(graph.degree())
    elif method == 'closeness': centrality = nx.closeness_centrality(graph)
    else: raise ValueError(f"Unknown method: {method}")
    sorted_nodes = sorted(centrality, key=centrality.get, reverse=True)
    return set(sorted_nodes[:n_vax])

def isolation_strategy(graph, isolation_rate, rng):
    def select_isolated(states):
        infectious = np.where(states == 2)[0]
        n_isolate = int(isolation_rate * len(infectious))
        if n_isolate > 0 and len(infectious) > 0:
            return set(rng.choice(infectious, size=min(n_isolate, len(infectious)), replace=False))
        return set()
    return select_isolated

def xai_guided_vaccination(graph, node_attribution_scores, fraction):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    sorted_nodes = sorted(range(N), key=lambda x: node_attribution_scores.get(x, 0), reverse=True)
    return set(sorted_nodes[:n_vax])

def xai_guided_edge_removal(graph, edge_attribution_scores, fraction):
    edges = list(graph.edges())
    n_remove = int(fraction * len(edges))
    sorted_edges = sorted(edges, key=lambda e: edge_attribution_scores.get((e[0], e[1]),
                                   edge_attribution_scores.get((e[1], e[0]), 0)), reverse=True)
    modified_graph = graph.copy()
    modified_graph.remove_edges_from(sorted_edges[:n_remove])
    return modified_graph
