"""
SEIHRD ODE Model for Bundibugyo Virus Disease
Extended SEIRD with Hospitalization and Funeral transmission routes
Calibrated to 2026 DRC/Uganda outbreak (R0=2.51, CFR=0.33)
"""
import numpy as np
from scipy.integrate import odeint

class SEIHRDModel:
    def __init__(self, params=None):
        if params is None:
            # Recalibrated parameters (R0_total = 2.51)
            beta = 0.676947
            self.params = {
                'beta': beta,
                'beta_H': 0.3 * beta,      # Hospital (reduced by IPC)
                'beta_F': 1.5 * beta,       # Funeral (amplified)
                'sigma': 1/8.5,             # 1/incubation
                'alpha': 1/3.0,             # Hospitalization rate
                'gamma_I': (1/5.6) * 0.6,   # Community exit rate
                'gamma_H': (1/5.6) * 1.5,   # Hospital exit rate
                'gamma_D': 0.5,             # Burial rate (2-day delay)
                'f_I': 0.33 * 1.2,          # Community CFR
                'f_H': 0.33 * 0.5,          # Hospital CFR
                'N': 4_392_200
            }
        else:
            self.params = params
        self._compute_R0()

    def _compute_R0(self):
        p = self.params
        denom = p['gamma_I'] + p['alpha']
        self.R0_community = p['beta'] / denom
        self.R0_hospital = (p['alpha'] / denom) * (p['beta_H'] / p['gamma_H'])
        self.R0_funeral = ((p['f_I'] * p['gamma_I'] + p['f_H'] * p['gamma_H']) / denom) * (p['beta_F'] / p['gamma_D'])
        self.R0 = self.R0_community + self.R0_hospital + self.R0_funeral

    def deriv(self, y, t):
        S, E, I, H, R, Dstar, D = y
        p = self.params
        N = p['N']
        lam = p['beta'] * I / N + p['beta_H'] * H / N + p['beta_F'] * Dstar / N
        dSdt = -lam * S
        dEdt = lam * S - p['sigma'] * E
        dIdt = p['sigma'] * E - (p['alpha'] + p['gamma_I']) * I
        dHdt = p['alpha'] * I - p['gamma_H'] * H
        dRdt = (1 - p['f_I']) * p['gamma_I'] * I + (1 - p['f_H']) * p['gamma_H'] * H
        dDstardt = p['f_I'] * p['gamma_I'] * I + p['f_H'] * p['gamma_H'] * H - p['gamma_D'] * Dstar
        dDdt = p['gamma_D'] * Dstar
        return [dSdt, dEdt, dIdt, dHdt, dRdt, dDstardt, dDdt]

    def simulate(self, t, I0=1):
        N = self.params['N']
        y0 = [N - I0, 0, I0, 0, 0, 0, 0]
        return odeint(self.deriv, y0, t)

    def get_metrics(self, sol, t):
        peak_I = max(sol[:, 2])
        peak_day = t[np.argmax(sol[:, 2])]
        peak_H = max(sol[:, 3])
        peak_Dstar = max(sol[:, 5])
        total_D = sol[-1, 6]
        N = self.params['N']
        attack_rate = (sol[-1, 4] + sol[-1, 6]) / N * 100
        return {
            'peak_infectious': int(peak_I),
            'peak_day': int(peak_day),
            'peak_hospitalized': int(peak_H),
            'peak_dead_not_buried': int(peak_Dstar),
            'total_deaths': int(total_D),
            'attack_rate_pct': round(attack_rate, 2),
            'R0': round(self.R0, 4),
            'R0_community': round(self.R0_community, 4),
            'R0_hospital': round(self.R0_hospital, 4),
            'R0_funeral': round(self.R0_funeral, 4)
        }
