"""
SEIRD ODE Model for Bundibugyo Virus Disease
Calibrated to 2026 DRC/Uganda outbreak (R0=2.51, CFR=0.33)
"""
import numpy as np
from scipy.integrate import odeint

class SEIRDModel:
    def __init__(self, params=None):
        self.params = params or {
            'beta': 2.51 / 5.6,   # R0/gamma
            'sigma': 1/8.5,        # 1/incubation
            'gamma': 1/5.6,        # 1/infectious_period
            'f': 0.33,             # CFR
            'N': 4_392_200         # Ituri province population
        }
        self.R0 = self.params['beta'] / self.params['gamma']

    def deriv(self, y, t):
        S, E, I, R, D = y
        p = self.params
        N = p['N']
        dSdt = -p['beta'] * S * I / N
        dEdt = p['beta'] * S * I / N - p['sigma'] * E
        dIdt = p['sigma'] * E - p['gamma'] * I
        dRdt = (1 - p['f']) * p['gamma'] * I
        dDdt = p['f'] * p['gamma'] * I
        return [dSdt, dEdt, dIdt, dRdt, dDdt]

    def simulate(self, t, I0=1):
        N = self.params['N']
        y0 = [N - I0, 0, I0, 0, 0]
        return odeint(self.deriv, y0, t)

    def get_metrics(self, sol, t):
        peak_I = max(sol[:, 2])
        peak_day = t[np.argmax(sol[:, 2])]
        total_D = sol[-1, 4]
        N = self.params['N']
        attack_rate = (sol[-1, 3] + sol[-1, 4]) / N * 100
        return {
            'peak_infectious': int(peak_I),
            'peak_day': int(peak_day),
            'total_deaths': int(total_D),
            'attack_rate_pct': round(attack_rate, 2),
            'R0': round(self.R0, 4)
        }
