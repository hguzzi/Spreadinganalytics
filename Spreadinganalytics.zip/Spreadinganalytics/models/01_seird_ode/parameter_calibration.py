"""
Parameter Calibration for Bundibugyo Virus Disease Models
Sources: Lancet ID 2026, CDC MMWR 2026, WHO, epireview
"""
import numpy as np
from scipy.optimize import brentq

# Bundibugyo-specific parameters from literature
BUNDIBUGYO_PARAMS = {
    'R0': 2.51,                    # IQI 2.27-2.82, CDC MMWR
    'R0_low': 2.27,
    'R0_high': 2.82,
    'CFR': 0.33,                   # 95% CI 0.26-0.40, Lancet ID
    'CFR_low': 0.26,
    'CFR_high': 0.40,
    'incubation_days': 8.5,         # Range 2-21, WHO
    'infectious_days': 5.6,         # Althaus/Chowell
    'onset_to_death_shape': 11.37,  # Gamma distribution, Lancet ID
    'onset_to_death_scale': 5.41,
    'doubling_time_days': 10,       # Lancet ID
    'hospitalization_days': 3.0,    # Time to hospitalization
    'burial_days': 2.0,             # Default burial delay
    'N_ituri': 4_392_200,
    'N_nord_kivu': 8_201_400,
    'spillover_date': '2026-02-19', # CDC MMWR
}

def calibrate_seird(R0=2.51, infectious_days=5.6, incubation_days=8.5, CFR=0.33):
    """Calibrate SEIRD parameters from epidemiological observables."""
    gamma = 1 / infectious_days
    sigma = 1 / incubation_days
    beta = R0 * gamma
    return {'beta': beta, 'sigma': sigma, 'gamma': gamma, 'f': CFR, 'R0': R0}

def calibrate_seihrd(R0=2.51, infectious_days=5.6, incubation_days=8.5, CFR=0.33,
                     theta_H=0.3, theta_F=1.5, hospitalization_days=3.0,
                     burial_days=2.0, hospital_cfr_ratio=0.5):
    """Calibrate SEIHRD parameters, solving for beta to match target R0."""
    sigma = 1 / incubation_days
    alpha = 1 / hospitalization_days
    gamma_I = (1 / infectious_days) * 0.6
    gamma_H = (1 / infectious_days) * 1.5
    gamma_D = 1 / burial_days
    f_I = CFR * 1.2
    f_H = CFR * hospital_cfr_ratio

    def compute_R0(beta):
        beta_H = theta_H * beta
        beta_F = theta_F * beta
        denom = gamma_I + alpha
        R0_comm = beta / denom
        R0_hosp = (alpha / denom) * (beta_H / gamma_H)
        R0_fun = ((f_I * gamma_I + f_H * gamma_H) / denom) * (beta_F / gamma_D)
        return R0_comm + R0_hosp + R0_fun

    beta = brentq(lambda b: compute_R0(b) - R0, 0.01, 5.0)
    return {
        'beta': beta, 'beta_H': theta_H * beta, 'beta_F': theta_F * beta,
        'sigma': sigma, 'alpha': alpha,
        'gamma_I': gamma_I, 'gamma_H': gamma_H, 'gamma_D': gamma_D,
        'f_I': f_I, 'f_H': f_H, 'R0': R0
    }

# Isolation scenarios from CDC MMWR
ISOLATION_SCENARIOS = {
    'poor': {'isolation_rate': 0.20, 'delay_days': 2},
    'moderate': {'isolation_rate': 0.50, 'delay_days': 2},
    'high': {'isolation_rate': 0.70, 'delay_days': 2},
    'extremely_high': {'isolation_rate': 0.95, 'delay_days': 2},
}

# Safe burial scenarios
SAFE_BURIAL_SCENARIOS = {
    'default': {'gamma_D': 0.5, 'burial_delay_days': 2.0},
    'improved': {'gamma_D': 1.0, 'burial_delay_days': 1.0},
    'safe': {'gamma_D': 2.0, 'burial_delay_days': 0.5},
    'unsafe': {'gamma_D': 0.25, 'burial_delay_days': 4.0},
}
