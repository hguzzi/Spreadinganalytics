"""
Ebola SEIHRD Network Simulation + GNN + XAI Module (FIXED)
==========================================================
Isolation bug corrected: isolated infectious nodes don't transmit.
Safe burial bug corrected: per-neighbor reduction in D* transmission.
"""

import numpy as np
import networkx as nx
import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data
import pickle
import json
import os
from collections import defaultdict

# Path configuration — resolved relative to the repository root
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import NETWORKS_DIR, RESULTS_DIR, ATTRIBUTIONS_DIR

STATE_NAMES_SEIHRD = {0: 'S', 1: 'E', 2: 'I', 3: 'H', 4: 'R', 5: 'D*', 6: 'D'}

class NetworkSEIHRDSimulation:
    """Stochastic SEIHRD simulation on a contact network (Ebola-specific).
    FIXED: Isolated infectious nodes don't transmit to neighbors.
    """
    
    def __init__(self, graph, params, I0=1, seed=None):
        self.graph = graph
        self.N = graph.number_of_nodes()
        self.params = params
        self.rng = np.random.default_rng(seed)
        self.I0 = I0
    
    def initialize_states(self):
        states = np.zeros(self.N, dtype=int)
        initial_infected = self.rng.choice(self.N, size=min(self.I0, self.N), replace=False)
        states[initial_infected] = 2
        return states
    
    def state_transition(self, states, vaccinated_nodes=None, isolated_nodes=None,
                        safe_burial_nodes=None):
        new_states = states.copy()
        p = self.params
        for node in range(self.N):
            current = states[node]
            if current == 0:  # Susceptible
                if vaccinated_nodes is not None and node in vaccinated_nodes:
                    new_states[node] = 4
                    continue
                neighbors = list(self.graph.neighbors(node))
                # FIXED: Isolated infectious nodes don't transmit
                n_I = sum(1 for nb in neighbors if states[nb] == 2 and 
                         (isolated_nodes is None or nb not in isolated_nodes))
                n_H = sum(1 for nb in neighbors if states[nb] == 3)
                # D* neighbors: safe burial reduces funeral transmission per-neighbor
                n_Dstar_eff = 0
                for nb in neighbors:
                    if states[nb] == 5:
                        if safe_burial_nodes is not None and nb in safe_burial_nodes:
                            n_Dstar_eff += 0.2
                        else:
                            n_Dstar_eff += 1
                
                prob_no_infection = 1.0
                if n_I > 0:
                    prob_no_infection *= (1 - p['beta']) ** n_I
                if n_H > 0:
                    prob_no_infection *= (1 - p['beta_H']) ** n_H
                if n_Dstar_eff > 0:
                    prob_no_infection *= (1 - p['beta_F']) ** n_Dstar_eff
                
                prob_infection = 1 - prob_no_infection
                if self.rng.random() < prob_infection:
                    new_states[node] = 1
            elif current == 1:  # Exposed
                if self.rng.random() < p['sigma']:
                    new_states[node] = 2
            elif current == 2:  # Infectious
                if self.rng.random() < p['alpha']:
                    new_states[node] = 3
                elif self.rng.random() < p['gamma_I']:
                    if self.rng.random() < p['f_I']:
                        new_states[node] = 5
                    else:
                        new_states[node] = 4
            elif current == 3:  # Hospitalized
                if self.rng.random() < p['gamma_H']:
                    if self.rng.random() < p['f_H']:
                        new_states[node] = 5
                    else:
                        new_states[node] = 4
            elif current == 5:  # Dead-not-buried
                gamma_D = p['gamma_D']
                if safe_burial_nodes is not None and node in safe_burial_nodes:
                    gamma_D = min(1.0, gamma_D * 4)
                if self.rng.random() < gamma_D:
                    new_states[node] = 6
        return new_states
    
    def simulate(self, n_steps, vaccinated_nodes=None, isolated_nodes=None,
                safe_burial_nodes=None):
        states = self.initialize_states()
        history = [states.copy()]
        for t in range(n_steps):
            states = self.state_transition(states, vaccinated_nodes, isolated_nodes,
                                          safe_burial_nodes)
            history.append(states.copy())
            active = np.sum(states == 2) + np.sum(states == 1) + np.sum(states == 3) + np.sum(states == 5)
            if active == 0:
                break
        return np.array(history)
    
    def compute_metrics(self, history):
        n_steps = len(history)
        counts = defaultdict(list)
        for t in range(n_steps):
            for state_id, name in STATE_NAMES_SEIHRD.items():
                counts[name].append(np.sum(history[t] == state_id))
        peak_I = max(counts['I'])
        peak_day = np.argmax(counts['I'])
        peak_H = max(counts['H'])
        peak_Dstar = max(counts['D*'])
        total_D = counts['D'][-1]
        total_R = counts['R'][-1]
        attack_rate = (total_R + total_D) / self.N * 100
        return {
            'peak_infectious': int(peak_I),
            'peak_day': int(peak_day),
            'peak_hospitalized': int(peak_H),
            'peak_dead_not_buried': int(peak_Dstar),
            'total_deaths': int(total_D),
            'total_recovered': int(total_R),
            'attack_rate_pct': round(attack_rate, 2),
            'epidemic_duration': n_steps,
            'final_S': int(counts['S'][-1]),
            'final_E': int(counts['E'][-1])
        }


class EbolaGCN(torch.nn.Module):
    def __init__(self, num_features=5, num_classes=7, hidden_dim=32, output_dim=16):
        super(EbolaGCN, self).__init__()
        self.conv1 = GCNConv(num_features, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, output_dim)
        self.fc = torch.nn.Linear(output_dim, num_classes)
    
    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.fc(x)
        return F.log_softmax(x, dim=1)


def create_dataloader(graph, history, model_type='seihrd', train_ratio=0.7):
    N = graph.number_of_nodes()
    edges = list(graph.edges())
    edge_list = []
    for u, v in edges:
        edge_list.append([u, v])
        edge_list.append([v, u])
    edge_index = torch.tensor(edge_list, dtype=torch.long).t().contiguous()
    num_classes = 7 if model_type == 'seihrd' else 5
    all_features = []
    all_labels = []
    n_steps = len(history)
    for t in range(n_steps - 1):
        states_curr = history[t]
        states_next = history[t + 1]
        adj = nx.to_numpy_array(graph)
        infected_mask = (states_curr == 2).astype(float)
        hospitalized_mask = (states_curr == 3).astype(float) if model_type == 'seihrd' else np.zeros(N)
        dead_not_buried_mask = (states_curr == 5).astype(float) if model_type == 'seihrd' else np.zeros(N)
        n_inf_neighbors = adj @ infected_mask
        n_hosp_neighbors = adj @ hospitalized_mask
        n_dead_neighbors = adj @ dead_not_buried_mask
        degrees = np.array([graph.degree(i) for i in range(N)])
        features = np.column_stack([
            states_curr, n_inf_neighbors, n_hosp_neighbors, n_dead_neighbors, degrees
        ]).astype(float)
        features[:, 1:] = features[:, 1:] / (features[:, 1:].max(axis=0) + 1e-8)
        all_features.append(features)
        all_labels.append(states_next)
    X = np.vstack(all_features)
    y = np.concatenate(all_labels)
    n_total = len(y)
    n_train = int(train_ratio * n_total)
    perm = np.random.permutation(n_total)
    train_mask = torch.zeros(n_total, dtype=torch.bool)
    test_mask = torch.zeros(n_total, dtype=torch.bool)
    train_mask[perm[:n_train]] = True
    test_mask[perm[n_train:]] = True
    data = Data(
        x=torch.tensor(X, dtype=torch.float),
        edge_index=edge_index,
        y=torch.tensor(y, dtype=torch.long),
        train_mask=train_mask,
        test_mask=test_mask
    )
    return data, num_classes


def train_gcn(graph, history, model_type='seihrd', epochs=100, lr=0.002):
    data, num_classes = create_dataloader(graph, history, model_type)
    labels = data.y[data.train_mask].numpy()
    unique, counts = np.unique(labels, return_counts=True)
    total = len(labels)
    weights = torch.zeros(max(unique) + 1)
    for cls, count in zip(unique, counts):
        weights[cls] = total / (len(unique) * count)
    model = EbolaGCN(num_features=5, num_classes=num_classes)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = torch.nn.NLLLoss(weight=weights)
    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(data.x, data.edge_index)
        loss = criterion(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        optimizer.step()
    model.eval()
    with torch.no_grad():
        out = model(data.x, data.edge_index)
        pred = out.argmax(dim=1)
        train_acc = (pred[data.train_mask] == data.y[data.train_mask]).float().mean()
        test_acc = (pred[data.test_mask] == data.y[data.test_mask]).float().mean()
    return model, data, {'train_acc': train_acc.item(), 'test_acc': test_acc.item()}


def compute_integrated_gradients(model, data, n_steps=50):
    model.eval()
    with torch.no_grad():
        output = model(data.x, data.edge_index)
        pred = output.argmax(dim=1)
    target = pred
    baseline_x = torch.zeros_like(data.x)
    total_grads = torch.zeros_like(data.x)
    for step in range(n_steps):
        alpha = (step + 1) / n_steps
        interp_x = baseline_x + alpha * (data.x - baseline_x)
        interp_x.requires_grad_(True)
        output = model(interp_x, data.edge_index)
        loss = output[range(len(target)), target].sum()
        loss.backward()
        total_grads += interp_x.grad.detach()
        interp_x.grad = None
    avg_grads = total_grads / n_steps
    ig_scores = (data.x - baseline_x) * avg_grads
    node_attr = ig_scores.detach().numpy()
    edge_attr = {}
    for i in range(data.edge_index.size(1)):
        u = data.edge_index[0, i].item()
        v = data.edge_index[1, i].item()
        score = np.sum(np.abs(node_attr[u])) + np.sum(np.abs(node_attr[v]))
        key = (min(u, v), max(u, v))
        edge_attr[key] = edge_attr.get(key, 0) + score
    if edge_attr:
        max_score = max(edge_attr.values())
        if max_score > 0:
            edge_attr = {k: v/max_score for k, v in edge_attr.items()}
    node_scores = defaultdict(float)
    for (u, v), score in edge_attr.items():
        node_scores[u] += score
        node_scores[v] += score
    return node_attr, dict(edge_attr), dict(node_scores)


def random_vaccination(graph, fraction, rng):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    return set(rng.choice(N, size=n_vax, replace=False))

def betweenness_vaccination(graph, fraction):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    centrality = nx.betweenness_centrality(graph)
    sorted_nodes = sorted(centrality, key=centrality.get, reverse=True)
    return set(sorted_nodes[:n_vax])

def xai_guided_vaccination(graph, node_attribution_scores, fraction):
    N = graph.number_of_nodes()
    n_vax = int(fraction * N)
    sorted_nodes = sorted(range(N), key=lambda x: node_attribution_scores.get(x, 0), reverse=True)
    return set(sorted_nodes[:n_vax])

def xai_guided_edge_removal(graph, edge_attribution_scores, fraction):
    edges = list(graph.edges())
    n_remove = int(fraction * len(edges))
    sorted_edges = sorted(edges, key=lambda e: edge_attribution_scores.get(
        (e[0], e[1]), edge_attribution_scores.get((e[1], e[0]), 0)), reverse=True)
    edges_to_remove = sorted_edges[:n_remove]
    modified_graph = graph.copy()
    modified_graph.remove_edges_from(edges_to_remove)
    return modified_graph

def make_standard_isolation(rate, rng):
    """Returns function that randomly isolates rate% of infectious nodes.
    Isolated nodes cannot transmit to their neighbors."""
    def select_isolated(states):
        infectious = np.where(states == 2)[0]
        n_isolate = int(rate * len(infectious))
        if n_isolate > 0 and len(infectious) > 0:
            return set(rng.choice(infectious, size=min(n_isolate, len(infectious)), replace=False))
        return set()
    return select_isolated

def make_xai_isolation(xai_scores, fraction):
    """Returns function that isolates top-XAI-scored infectious nodes.
    Isolated nodes cannot transmit to their neighbors."""
    def select_isolated(states):
        infectious = np.where(states == 2)[0]
        n_isolate = int(fraction * len(infectious))
        if n_isolate > 0 and len(infectious) > 0:
            sorted_inf = sorted(infectious, key=lambda x: xai_scores.get(x, 0), reverse=True)
            return set(sorted_inf[:n_isolate])
        return set()
    return select_isolated


def build_seihrd_params(R0=2.51, f=0.33, sigma=1/8.5, alpha=1/3.0, avg_degree=5.96):
    """Build SEIHRD network parameters from high-level epidemiological quantities."""
    baseline_R0 = 2.51
    baseline_beta = 0.676947
    baseline_beta_H = 0.203084
    baseline_beta_F = 1.015421
    R0_ratio = R0 / baseline_R0
    beta = baseline_beta * R0_ratio / avg_degree
    beta_H = baseline_beta_H * R0_ratio / avg_degree
    beta_F = baseline_beta_F * R0_ratio / avg_degree
    baseline_f_I = 0.396
    baseline_f_H = 0.165
    f_I = f * (baseline_f_I / 0.33)
    f_H = f * (baseline_f_H / 0.33)
    gamma_I = 1/5.6
    gamma_H = 1/3.73
    gamma_D = 0.5
    return {
        'beta': beta, 'beta_H': beta_H, 'beta_F': beta_F,
        'sigma': sigma, 'alpha': alpha,
        'gamma_I': gamma_I, 'gamma_H': gamma_H, 'gamma_D': gamma_D,
        'f_I': f_I, 'f_H': f_H
    }


def run_simulation(graph, params, I0=3, n_steps=100, seed=42,
                   vaccinated_nodes=None, isolated_func=None,
                   safe_burial_nodes=None):
    """Run SEIHRD simulation with intervention, return metrics + history."""
    sim = NetworkSEIHRDSimulation(graph, params, I0=I0, seed=seed)
    if isolated_func is not None:
        states = sim.initialize_states()
        history = [states.copy()]
        for t in range(n_steps):
            iso_nodes = isolated_func(states)
            states = sim.state_transition(states, vaccinated_nodes,
                                         iso_nodes if iso_nodes else None,
                                         safe_burial_nodes)
            history.append(states.copy())
            active = np.sum(states == 2) + np.sum(states == 1) + np.sum(states == 3) + np.sum(states == 5)
            if active == 0:
                break
        history = np.array(history)
    else:
        history = sim.simulate(n_steps, vaccinated_nodes=vaccinated_nodes,
                              safe_burial_nodes=safe_burial_nodes)
    metrics = sim.compute_metrics(history)
    return metrics, history


DATA_DIR = str(NETWORKS_DIR)
RESULTS_DIR = str(RESULTS_DIR)

def load_calibrated_params():
    with open(f'{RESULTS_DIR}/calibrated_params.json', 'r') as f:
        return json.load(f)

def load_network(name, N=500):
    fname = f'{DATA_DIR}/{name}_N{N}.edgelist'
    g = nx.read_edgelist(fname)
    g = nx.convert_node_labels_to_integers(g)
    return g

def load_xai_attributions(network_name):
    with open(ATTRIBUTIONS_DIR / 'xai_attributions_all_networks.pkl', 'rb') as f:
        all_xai = pickle.load(f)
    return all_xai[network_name]

def get_network_avg_degree(graph):
    return 2 * graph.number_of_edges() / graph.number_of_nodes()

def get_baseline_seihrd_params(avg_degree):
    cal = load_calibrated_params()
    p = cal['seihrd']
    return {
        'beta': p['beta'] / avg_degree,
        'beta_H': p['beta_H'] / avg_degree,
        'beta_F': p['beta_F'] / avg_degree,
        'sigma': p['sigma'], 'alpha': p['alpha'],
        'gamma_I': p['gamma_I'], 'gamma_H': p['gamma_H'], 'gamma_D': p['gamma_D'],
        'f_I': p['f_I'], 'f_H': p['f_H']
    }
